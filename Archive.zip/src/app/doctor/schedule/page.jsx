"use client"
import FullCalendar from '@fullcalendar/react'
import dayGridPlugin from '@fullcalendar/daygrid' // a plugin!
import React, { useEffect, useState } from 'react'
// import multiMonthPlugin from '@fullcalendar/multimonth'
import timeGridPlugin from '@fullcalendar/timegrid'
import './css/customCalenderStyle.css'
import { useAppContext } from '@/context/AppContext'
import axios from 'axios'
import { useDoctorAppointments } from '@/hooks/useDoctorAppointments'



const page = () => {
    const { user } = useAppContext()
    const { data: appointments, isLoading, error } = useDoctorAppointments(user.userId);
    // console.log(appointments, isLoading, error);

    const events = appointments?.map(appt => {
        const start = new Date(`${appt.date.slice(0, 10)}T${appt.time}:00`);
        return {
            id: appt.id,
            title: appt.patientName,
            date: start,
            extendedProps: {
                patientId: appt.patientNumber,
                doctorName: appt.doctorName,
                status: appt.status
            }
        }
    });
    console.log(events);

    const docColor = (role) => {
        switch (role) {
            case 'radiologist':
                return '#DA9100'
                break
        }
    }
    const appointment = [
        {
            title: 'Medical Assesment',
            date: '2025-10-07T09:30:00',
            dotColor: docColor('radiologist')
        },
        {
            title: 'Team Meetings',
            start: '2025-10-25T11:00:00',
            end: '2025-07-25T13:30:00'
        },
        {
            title: 'MRI Scan',
            start: '2025-10-25T10:00:00',
            end: '2025-07-25T11:30:00'
        },
        {
            title: 'Check Up',
            start: '2025-10-20T12:00:00',
            end: '2025-07-20T13:30:00',

        },
        {
            title: 'Check Up',
            start: '2025-07-20T12:30:00',
            end: '2025-07-20T14:00:00',

        },
        {
            title: 'Check Up',
            start: '2025-07-20T14:30:00',
            end: '2025-07-20T15:00:00',

        }
    ]

    // useEffect(() => {
    //     if (user.userId) {
    //         fetchAppt(user?.userId)
    //         console.log();
    //     }
    // }, [user])

    return (
        <div className='p-2 sm:p-3 min-h-screen flex flex-col'>
            <div className='flex-1 min-h-0 rounded-lg overflow-auto'>
                <FullCalendar
                    height='100%'
                    contentHeight="auto"
                    dayMaxEventRows={2} // Show max 2 rows of events per day
                    fixedWeekCount={true} // forces all months to have 6 rows
                    plugins={[dayGridPlugin, timeGridPlugin]}
                    // weekends={false}
                    initialView="dayGridMonth"
                    headerToolbar={{
                        left: 'prev,next today',
                        center: 'title',
                        right: 'timeGridDay,timeGridWeek,dayGridMonth'
                    }}
                    editable={true}
                    selectable={true}
                    events={events}
                    eventDidMount={(info) => {
                        const dotEl = info.el.querySelector('.fc-daygrid-event-dot');
                        if (dotEl && info.event.extendedProps.dotColor) {
                            dotEl.style.borderColor = info.event.extendedProps.dotColor;
                        }
                    }}
                />
            </div>
        </div>
    )
}

export default page